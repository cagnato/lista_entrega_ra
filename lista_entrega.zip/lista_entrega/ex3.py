lista = []

frase = input("Digite uma frase: ").split()

lista.append(frase)

print(lista)
