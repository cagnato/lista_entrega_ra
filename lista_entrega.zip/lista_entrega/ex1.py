import random

lista = [random.randint(0, 100)]

print(lista)
