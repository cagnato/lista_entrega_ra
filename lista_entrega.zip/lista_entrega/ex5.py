lista = []

for i in range(3):
    palavra = input(f"Digite a {1+i}º palavra: ")
    lista.append(palavra)
    menorPalavra = min(lista)
    maiorPalavra = max(lista)

print(f"A maior palavra da lista {lista} é {maiorPalavra}, já a menor palavra é {menorPalavra}: ")