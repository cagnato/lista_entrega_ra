lista = []

for i in range(3):
    num = int(input(f"Digite o {1+i}º número: "))
    lista.append(num)

print(lista)